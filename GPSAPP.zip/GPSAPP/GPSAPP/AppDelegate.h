//
//  AppDelegate.h
//  GPSAPP
//
//  Created by Mackintosh on 29/12/14.
//  Copyright (c) 2014 Shirish Gayakawad. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
