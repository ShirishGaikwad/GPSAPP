//
//  ViewController.h
//  GPSAPP
//
//  Created by Mackintosh on 29/12/14.
//  Copyright (c) 2014 Shirish Gayakawad. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

@interface ViewController : UIViewController
- (IBAction)btnStart:(id)sender;
- (IBAction)btnStop:(id)sender;
@property (retain, nonatomic) IBOutlet MKMapView *mapView;
@property(nonatomic,strong)CLLocationManager *locationManager;

@end
