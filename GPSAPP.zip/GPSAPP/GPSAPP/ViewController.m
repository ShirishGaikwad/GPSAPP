//
//  ViewController.m
//  GPSAPP
//
//  Created by Mackintosh on 29/12/14.
//  Copyright (c) 2014 Shirish Gayakawad. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize mapView,locationManager;


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.locationManager = [[CLLocationManager alloc]init];
    self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    self.locationManager.delegate = self;
    
}

- (void)locationManager:(CLLocationManager *)manager
didUpdateToLocation:(CLLocation *)newLocation
fromLocation:(CLLocation *)oldLocation __OSX_AVAILABLE_BUT_DEPRECATED(__MAC_10_6, __MAC_NA, __IPHONE_2_0, __IPHONE_6_0);

{
    [self.mapView setRegion:MKCoordinateRegionMake(newLocation.coordinate, self.mapView.region.span) animated:YES];
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnStart:(id)sender
{
    
    [self.locationManager startUpdatingLocation];

}

- (IBAction)btnStop:(id)sender
{
    
    [self.locationManager stopUpdatingLocation];
}
- (void)dealloc {
    [mapView release];
    [super dealloc];
}
@end
